import { utilizationMetrics } from '../engine/utilization.mjs';

export function quantile(values, q) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.max(0, Math.min(sorted.length - 1, Math.ceil(sorted.length * q) - 1))];
}
export function evaluate(world) {
  const events = world.log,
    needs = world.state.needs;
  const services = {};
  for (const n of needs) {
    const row = (services[n.type] ??= {
      unit: n.unit,
      demand: 0,
      served: 0,
      pending: 0,
      overprovided: 0,
      uncoveredUnitMs: 0,
      onTime: 0,
    });
    row.demand += n.quantity;
    row.served += Math.min(n.quantity, n.served);
    row.pending += Math.max(0, n.quantity - n.served);
    row.overprovided += Math.max(0, n.served - n.quantity);
    row.uncoveredUnitMs +=
      n.pendingIntegral + (world.now - n.integratedAt) * Math.max(0, n.quantity - n.served);
    if (n.quantity > 0 && n.served >= n.quantity && n.completedAt != null && n.completedAt <= n.deadline) row.onTime++;
  }
  const stages = {};
  for (const op of world.state.operations)
    for (const [stage, at] of Object.entries(op.times ?? {})) {
      if (!stages[stage]) stages[stage] = [];
      stages[stage].push(at - op.createdAt);
    }
  const latency = {};
  for (const [stage, values] of Object.entries(stages))
    latency[stage] = {
      p50: quantile(values, 0.5),
      p95: quantile(values, 0.95),
      samples: values.length,
    };
  const perCommunity = needs.map((n) => ({
    id: n.id,
    building: n.building,
    type: n.type,
    quantity: n.quantity,
    served: Math.min(n.quantity, n.served),
    firstServiceAt: n.firstServiceAt ?? null,
    sufficientServiceAt: n.completedAt,
    completedAt: n.completedAt,
    createdAt: n.responseCreatedAt ?? n.createdAt ?? n.occurredAt ?? 0,
    originalCreatedAt: n.createdAt ?? n.occurredAt ?? 0,
    responseEpisode: n.demandEpisodes?.at(-1)?.index ?? 1,
    responseState: n.demandEpisodes?.at(-1)?.state ?? (n.completedAt != null ? 'covered' : 'open'),
    deadline: n.deadline,
    silent: n.silent,
    firstSignalAt: world.state.statistics.firstSignalAt[n.id] ?? null,
    remote: world.sector(world.building(n.building).sector)?.terrain !== 'urban',
    knownBy: Object.entries(world.state.observations)
      .filter(([, o]) => o.needs[n.id])
      .map(([id]) => id),
  }));
  const eligibleCommunities = perCommunity.filter((n) => n.quantity > 0 && n.responseState !== 'retired'),
    firstUsefulCompleted = eligibleCommunities.filter((n) => n.firstServiceAt != null),
    sufficientlyCompleted = eligibleCommunities.filter((n) => n.completedAt != null && n.served >= n.quantity),
    sufficientServiceMs = {
      p50: quantile(sufficientlyCompleted.map((n) => n.completedAt - n.createdAt), 0.5),
      p95: quantile(sufficientlyCompleted.map((n) => n.completedAt - n.createdAt), 0.95),
      samples: sufficientlyCompleted.length,
      note: 'Sufficient physical service, completed positive-demand cases only; report right-censored cases alongside these percentiles.',
    },
    responseEpisodes = needs.flatMap((n) => (n.demandEpisodes ?? [{
      index: 1,
      startedAt: n.createdAt ?? n.occurredAt ?? 0,
      baselineServed: 0,
      quantity: n.quantity,
      peakQuantity: n.quantity,
      targetQuantity: n.quantity,
      firstServiceAt: n.firstServiceAt ?? null,
      completedAt: n.completedAt ?? null,
      endedAt: n.completedAt ?? null,
      state: n.completedAt != null ? 'covered' : n.quantity > 0 ? 'open' : 'retired',
      pendingIntegral: n.pendingIntegral ?? 0,
    }]).filter((e) => e.peakQuantity > 0).map((e) => {
      const firstServiceAt = e.firstServiceAt ?? null,
        completedAt = e.state === 'covered' ? e.completedAt : null,
        censoredAt = e.endedAt ?? world.now;
      return {
        need: n.id,
        episode: e.index,
        building: n.building,
        type: e.type ?? n.type,
        unit: e.unit ?? n.unit,
        startedAt: e.startedAt,
        quantity: e.quantity,
        peakQuantity: e.peakQuantity,
        targetQuantity: e.targetQuantity,
        baselineServed: e.baselineServed,
        state: e.state,
        closedReason: e.closedReason ?? null,
        endedAt: e.endedAt ?? null,
        firstServiceAt,
        sufficientServiceAt: completedAt,
        firstUsefulCensored: firstServiceAt === null,
        sufficientCensored: completedAt === null,
        censoredAt: completedAt === null ? censoredAt : null,
        timeToFirstUsefulServiceMs: (firstServiceAt ?? censoredAt) - e.startedAt,
        timeToSufficientServiceMs: (completedAt ?? censoredAt) - e.startedAt,
        uncoveredUnitMs: e.pendingIntegral +
          (e.state === 'open' ? Math.max(0, world.now - n.integratedAt) * Math.max(0, n.quantity - n.served) : 0),
      };
    }));
  return {
    simulatedMs: world.now,
    utilization: utilizationMetrics(world),
    humanCapacity: evaluateHumanCapacity(world),
    services,
    collective:{shelterPlaceHours:world.state.map.buildings.filter(b=>b.use==='shelter').reduce((s,b)=>s+((b.servedPlaceMs??0)+(b.state==='operating'?Math.max(0,world.now-(b.serviceIntegratedAt??world.now))*(b.occupancy??0):0))/3600000,0),operatingHours:world.state.map.buildings.reduce((s,b)=>s+((b.operatingMs??0)+(b.state==='operating'?Math.max(0,world.now-(b.serviceIntegratedAt??world.now)):0))/3600000,0),waterProduced:world.state.resources.filter(r=>r.id.startsWith('production-')).reduce((s,r)=>s+(r.produced??0),0),note:'Operating hours alone are not useful service. Occupied shelter place-hours and finite water production are measured separately.'},
    population: world.populationMetrics(),
    perCommunity,
    latency,
    posts: world.state.posts.length,
    ingested: world.state.ingestion.length,
    operations: world.state.operations.length,
    operatorReviewMs: world.state.statistics.reviewMs,
    conflicts: world.state.statistics.counts.reservation_conflict ?? 0,
    failedTrips: world.state.operations.filter((o) => o.state === 'failed').length,
    staleOrders: world.state.statistics.counts.message_expired ?? 0,
    queries: world.state.queryCount,
    cost: world.state.toolCost,
    events: world.eventCount,
    modelCalls: world.state.modelCalls ?? 0,
    modelWallMs: world.state.modelWallMs ?? 0,
    modelUsage: {
      promptTokens: (world.state.modelRequests ?? []).reduce(
        (n, r) => n + (r.promptTokens ?? 0),
        0,
      ),
      outputTokens: (world.state.modelRequests ?? []).reduce(
        (n, r) => n + (r.outputTokens ?? 0),
        0,
      ),
      pending: (world.state.modelRequests ?? []).filter((r) => r.state === 'waiting').length,
      failed: (world.state.modelRequests ?? []).filter((r) => r.failed).length,
      providerCost: (world.state.modelRequests ?? []).some((r) => r.providerCost !== undefined)
        ? (world.state.modelRequests ?? []).reduce((n, r) => n + (r.providerCost ?? 0), 0)
        : null,
    },
    platformTransport: {
      attempts: events.filter(e=>e.type==='platform_peer_transport').length,
      disconnected: events.filter(e=>e.type==='platform_peer_transport' && e.data?.state==='disconnected').length,
      bytes: events.filter(e=>e.type==='platform_peer_transport').reduce((s,e)=>s+(e.data?.bytes??0),0),
      note: 'Actual platform peer HTTP is charged by the laboratory transport adapter; this is distinct from source-system messages.',
    },
    invalidActions: world.state.invalidActions,
    ledgerValid: world.invariants().length === 0,
    source: {
      created: world.state.posts.length,
      published: world.state.statistics.counts.post_published ?? 0,
      falseSignals: world.state.statistics.falseSignals ?? 0,
      deleted: world.state.statistics.counts.post_deleted ?? 0,
      capped: !!world.state.postBudgetReached,
    },
    information: evaluateInformation(world),
    coordination: {
      expired: world.state.commitments.filter((c) => c.state === 'expired').length,
      withdrawn: world.state.commitments.filter((c) => c.state === 'withdrawn').length,
      orphanReservations: world.state.commitments.filter(
        (c) => ['confirmed', 'reserved'].includes(c.state) && c.expiresAt <= world.now,
      ).length,
      clarifications: world.state.proposals.filter((p) => p.state === 'needs_clarification').length,
      reviewQueued: world.state.proposals.filter((p) => p.reviewPending).length,
      loansOverdue: world.state.transfers?.filter((t) => t.state === 'overdue').length ?? 0,
    },
    physical: {
      closedCrossings: (world.state.map.crossings ?? []).filter((b) =>
        b.edges.some((id) => !world.edge(id).open),
      ).length,
      trafficQueue: world.state.map.edges.reduce((n, e) => n + e.waiting.length, 0),
      overprovidedByType: Object.fromEntries(
        Object.entries(services).map(([type, row]) => [
          type,
          { quantity: row.overprovided, unit: row.unit },
        ]),
      ),
      distanceM: world.state.vehicles.reduce((s, v) => s + (v.distanceM ?? 0), 0),
      fuelMl: world.state.vehicles.reduce((s, v) => s + v.fuelUsed, 0),
      arrivedNotReceived: world.state.operations.filter(
        (o) => o.times?.arrived !== undefined && o.times.received === undefined,
      ).length,
      facilitiesOperating: world.state.map.buildings.filter((b) => b.state === 'operating').length,
      blocked: world.state.operations.filter((o) => o.state === 'blocked').length,
    },
    finance: {
      sandbox: true,
      available: world.state.map.organizations.reduce((s, o) => s + o.funds, 0),
      spent: world.state.fundEntries
        .filter((e) => e.type === 'spent')
        .reduce((s, e) => s + e.amount, 0),
      received: world.state.fundEntries
        .filter((e) => e.type === 'received')
        .reduce((s, e) => s + e.amount, 0),
    },
    subgroups: subgroups(eligibleCommunities, world.now),
    response: {
      eligibleNeeds: eligibleCommunities.length,
      completed: sufficientlyCompleted.length,
      rightCensored: eligibleCommunities.length - sufficientlyCompleted.length,
      firstUsefulCompleted: firstUsefulCompleted.length,
      firstUsefulRightCensored: eligibleCommunities.length - firstUsefulCompleted.length,
      firstUsefulServiceMs: {
        p50: quantile(firstUsefulCompleted.map((n) => n.firstServiceAt - n.createdAt), 0.5),
        p95: quantile(firstUsefulCompleted.map((n) => n.firstServiceAt - n.createdAt), 0.95),
        samples: firstUsefulCompleted.length,
        note: 'First physical positive contribution to outstanding demand; partial service counts here, but not as sufficient service. Report firstUsefulRightCensored separately.',
      },
      sufficientServiceMs,
      needToServiceMs: sufficientServiceMs,
      excludedNonpositiveNeeds: perCommunity.filter((n) => n.quantity <= 0).length,
      excludedRetiredPositiveNeeds: perCommunity.filter((n) => n.quantity > 0 && n.responseState === 'retired').length,
      episodes: {
        eligible: responseEpisodes.length,
        completed: responseEpisodes.filter((e) => !e.sufficientCensored).length,
        retired: responseEpisodes.filter((e) => e.state === 'retired').length,
        rightCensored: responseEpisodes.filter((e) => e.sufficientCensored).length,
        perEpisode: responseEpisodes,
        note: 'A new outstanding shortfall after coverage or retirement starts a new episode. Earlier aid is retained in history, never credited as response to a new episode. Withdrawn episodes are censored at withdrawal and must be reported separately; native resource quantities and integrals are not summed across types.',
      },
    },
    eventCounts: { ...world.state.statistics.counts },
  };
}
function evaluateHumanCapacity(w) {
  const tasks=w.state.humanWork??[];
  const aggregate=rows=>{
    const finished=rows.filter(t=>['completed','inconclusive','failed'].includes(t.state)),
      started=rows.filter(t=>t.startedAt!=null),queued=rows.filter(t=>t.state==='queued');
    return {received:rows.length,completed:rows.filter(t=>t.state==='completed').length,
      inconclusive:rows.filter(t=>t.state==='inconclusive').length,failed:rows.filter(t=>t.state==='failed').length,
      queued:queued.length,working:rows.filter(t=>t.state==='working').length,
      awaitingDelivery:rows.filter(t=>t.state==='awaiting_delivery').length,
      elapsedWorkPersonMs:started.reduce((s,t)=>s+Math.max(0,Math.min(w.now,t.readyAt)-t.startedAt),0),
      elapsedQueuePersonMs:rows.reduce((s,t)=>s+Math.max(0,(t.startedAt??t.completedAt??w.now)-t.createdAt),0),
      startedQueueMs:{p50:quantile(started.map(t=>t.queueMs),.5),p95:quantile(started.map(t=>t.queueMs),.95),samples:started.length},
      finishedTurnaroundMs:{p50:quantile(finished.map(t=>t.completedAt-t.createdAt),.5),
        p95:quantile(finished.map(t=>t.completedAt-t.createdAt),.95),samples:finished.length},
      pendingCensored:rows.filter(t=>!['completed','inconclusive','failed'].includes(t.state)).length,
      pendingCensoredAt:w.now};
  };
  const grouped=rows=>Object.fromEntries(['read','decide','relay'].map(stage=>[stage,aggregate(rows.filter(t=>t.stage===stage))]));
  return {profile:structuredClone(w.config.humanCapacity),stages:grouped(tasks),
    perOrg:Object.fromEntries(Object.entries(w.state.humanCapacity?.orgs??{}).map(([org,s])=>[org,
      {stages:grouped(tasks.filter(t=>t.org===org)),maximumBacklog:s.maximumBacklog,observedAt:s.observedAt,version:s.version}])),
    maximumBacklog:Math.max(0,...Object.values(w.state.humanCapacity?.orgs??{}).map(o=>o.maximumBacklog)),
    backgroundDropped:w.state.humanCapacity?.backgroundDropped??0,
    note:'Declared experimental staffing and work durations, not empirical human performance. Person-ms counts attention work or waiting, not wages or productivity. Percentiles exclude pending work; pending counts and cutoff are reported separately. Work receipt/relay/owner approval never counts as physical aid. Attention lapses are explicit inconclusive outcomes, not invented false facts.'};
}
function evaluateInformation(w) {
  const downloaded = new Set(),
    accepted = new Set(),
    interpreted = new Set(),
    discarded = new Set();
  const latency = [];
  for (const r of w.state.ingestion) {
    const key = `${r.org}:${r.id}:${r.version}`;
    ({ downloaded, accepted, interpreted, discarded })[r.stage]?.add(key);
    if (r.stage === 'downloaded') {
      const p = w.post(r.id);
      if (p?.public.publishedAt != null) latency.push(r.at - p.public.publishedAt);
    }
  }
  let confirmedFalse = 0,
    rejectedTrue = 0,
    falseMerges = 0;
  for (const c of w.state.claims) {
    const posts = c.references.map((id) => w.post(id)).filter(Boolean);
    if (c.state === 'confirmed' && posts.some((p) => p.private.false)) confirmedFalse++;
    if (
      ['old', 'contradicted'].includes(c.state) &&
      posts.some((p) => p.private.truthCategory === 'observed' && !p.private.false)
    )
      rejectedTrue++;
    const needs = new Set(posts.map((p) => p.private.need).filter(Boolean));
    if (c.relation === 'same_incident' && needs.size > 1) falseMerges++;
  }
  return {
    downloaded: downloaded.size,
    accepted: accepted.size,
    interpreted: interpreted.size,
    discarded: discarded.size,
    downloadLatencyMs: { p50: quantile(latency, 0.5), p95: quantile(latency, 0.95) },
    confirmedFalse,
    rejectedObservedTrue: rejectedTrue,
    falseMerges,
    unobservedNeeds: w.state.needs.filter(
      (n) => n.quantity > 0 && !Object.values(w.state.observations).some((o) => o.needs[n.id]),
    ).length,
    note: 'These counts cover source-world claims only, not claims in an external platform database. Workflow acknowledgments are not semantic accuracy. Platform precision/recall requires matched external claims and independent task annotations.',
  };
}
function subgroups(rows, now) {
  return Object.fromEntries(
    ['silent', 'remote'].map((group) => [
      group,
      Object.fromEntries(
        [true, false].map((value) => {
          const byType = {};
          for (const n of rows.filter((n) => n[group] === value)) {
            const r = (byType[n.type] ??= { needs: 0, demand: 0, served: 0, missedDeadline: 0, pendingBeforeDeadline: 0, rightCensored: 0 });
            r.needs++;
            r.demand += n.quantity;
            r.served += n.served;
            if (n.completedAt !== null && n.completedAt > n.deadline) r.missedDeadline++;
            if (n.completedAt === null) {
              r.rightCensored++;
              if (now >= n.deadline) r.missedDeadline++;
              else r.pendingBeforeDeadline++;
            }
          }
          return [String(value), byType];
        }),
      ),
    ]),
  );
}
export const METRIC_RULES = {
  pendingWater: 'Sum max(0, demand − served) for water needs, in litres.',
  servedWater:
    'Sum min(demand, delivered service) for water needs. Arrivals and proposals are excluded.',
  signals: 'Publications and distinct versioned download receipts are separate counts.',
  operations: 'Authorized physical operations not in a terminal state.',
  responseEpisodes: 'Each return to outstanding demand after coverage/retirement starts a new response clock. Partial aid is first useful service, not sufficient service. Withdrawals remain separately censored in episode history; no delivery timestamp is inherited by a new episode.',
  integrity:
    'Per-resource conservation, reservations, vehicle capacity, population and stage ordering.',
};
