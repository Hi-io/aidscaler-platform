import test from "node:test";
import assert from "node:assert/strict";
import { Store } from "../src/store.mjs";
import { Domain } from "../src/domain.mjs";
import { Network } from "../src/network.mjs";
import { Finance } from "../src/finance.mjs";
const actor = {
  id: "commander-a",
  name: "Alex",
  org: "org0",
  role: "commander",
};
const draft = {
  title: "Deliver water to East shelter",
  summary: "Deliver a verified water allocation.",
  benefit: "600 L for a shelter with an unmet requirement.",
  references: ["post-a"],
  conditions: [],
  alternatives: [],
  actions: [
    {
      type: "dispatch",
      owner: "org0",
      params: {
        need: "need-a",
        quantity: 600,
        resource: "water-a",
        vehicle: "truck-a",
      },
      dependsOn: [],
    },
  ],
  priority: "urgent",
  rationale: "Need and available capacity were checked.",
};
async function setup(t) {
  const s = await Store.open();
  await s.organization("org0");
  await s.organization("org1");
  t.after(() => s.close());
  const d = new Domain(s, { peers: [{ org: "org1" }] });
  await s.put(
    "org0",
    "need",
    "need-a",
    { type: "water", quantity: 600, served: 0 },
    0,
  );
  await s.put(
    "org0",
    "signal",
    "post-a",
    { text: "Water is needed", sourceVersion: 1 },
    0,
  );
  await s.put(
    "org0",
    "resource",
    "water-a",
    { type: "water", quantity: 600, reserved: 0, floor: 0, owner: "org0" },
    0,
  );
  await s.put(
    "org0",
    "vehicle",
    "truck-a",
    { capacity: 600, state: "idle", owner: "org0" },
    0,
  );
  return { s, d };
}
test("evidence, owner, acyclic dependency and human authorization are enforced", async (t) => {
  const { s, d } = await setup(t);
  await assert.rejects(
    () => d.propose(actor, { ...draft, references: ["invented"] }, "missing"),
    /accessible evidence/,
  );
  await assert.rejects(
    () =>
      d.propose(
        actor,
        { ...draft, actions: [{ ...draft.actions[0], dependsOn: [0] }] },
        "cycle",
      ),
    /acyclic/,
  );
  const p = await d.propose(
    { id: "agent", org: "org0", role: "agent" },
    draft,
    "propose-1",
  );
  await assert.rejects(
    () =>
      d.review(
        { id: "agent", org: "org0", role: "agent" },
        p.id,
        { decision: "approve", version: p.version },
        "fake-approval",
      ),
    /role/,
  );
  const approved = await d.review(
    actor,
    p.id,
    { decision: "approve", version: p.version },
    "review-1",
  );
  assert.equal(approved.state, "authorized");
  assert.equal(approved.authorization.by, actor.id);
  assert.equal(
    approved.authorization.evidence[0].snapshot.text,
    "Water is needed",
  );
  await s.upsert("org0", "signal", "post-a", {
    text: "Correction: demand changed",
  });
  assert.equal(
    approved.authorization.evidence[0].snapshot.text,
    "Water is needed",
  );
  await assert.rejects(
    () =>
      d.review(
        actor,
        p.id,
        { decision: "approve", version: p.version },
        "stale",
      ),
    /changed/,
  );
});
test("concurrent reservations, reserve floors, retries, expiry and release preserve stock", async (t) => {
  const { s, d } = await setup(t);
  const r = await d.resource(
    actor,
    { id: "stock", type: "water", quantity: 100, floor: 20 },
    "stock-create",
  );
  const input = { resource: r.id, quantity: 60, version: r.version };
  const results = await Promise.allSettled([
    d.reserve(actor, input, "reservation-a"),
    d.reserve(actor, input, "reservation-b"),
  ]);
  assert.equal(results.filter((r) => r.status === "fulfilled").length, 1);
  const c = results.find((r) => r.status === "fulfilled").value;
  assert.equal((await s.get("org0", "resource", "stock")).reserved, 60);
  const key =
    results[0].status === "fulfilled" ? "reservation-a" : "reservation-b";
  assert.equal((await d.reserve(actor, input, key)).id, c.id);
  await assert.rejects(
    () => d.reserve(actor, { ...input, quantity: 10 }, key),
    /different command/,
  );
  await d.commitment(
    actor,
    c.id,
    { action: "withdraw", version: c.version },
    "withdraw",
  );
  assert.equal((await s.get("org0", "resource", "stock")).reserved, 0);
  const changed = await s.get("org0", "resource", "stock");
  const expired = await d.reserve(
    actor,
    { resource: "stock", quantity: 10, version: changed.version, ttlMs: 1000 },
    "expiry",
  );
  await s.upsert("org0", "commitment", expired.id, {
    expiresAt: Date.now() - 1,
  });
  await d.expire("org0", expired.id);
  assert.equal((await s.get("org0", "resource", "stock")).reserved, 0);
});
test("tenant isolation and targeted invalidation preserve unrelated authorizations", async (t) => {
  const { s, d } = await setup(t);
  const p = await d.propose(actor, draft, "propose-a");
  await s.put("org0", "signal", "post-b", { text: "An independent need" }, 0);
  const q = await d.propose(
    actor,
    {
      ...draft,
      references: ["post-b"],
      actions: [
        {
          type: "coverage",
          owner: "org0",
          params: {},
          dependsOn: [],
        },
      ],
    },
    "propose-b",
  );
  await d.review(
    actor,
    p.id,
    { version: p.version, decision: "approve" },
    "approve-a",
  );
  await d.review(
    actor,
    q.id,
    { version: q.version, decision: "approve" },
    "approve-b",
  );
  await assert.rejects(() => s.get("org1", "proposal", p.id), /not found/);
  const affected = await d.invalidate(
    actor,
    "post-a",
    "New information",
    "invalidate-a",
  );
  assert.deepEqual(affected.affected, [p.id]);
  assert.equal((await s.get("org0", "proposal", p.id)).authorization, null);
  assert.equal((await s.get("org0", "proposal", q.id)).state, "authorized");
});
test("conditional decisions cannot trigger physical execution", async (t) => {
  const { s, d } = await setup(t);
  const p = await d.propose(
    actor,
    {
      ...draft,
      conditions: [
        {
          type: "inspection",
          id: "site",
          description: "Building safety must be checked",
          satisfied: false,
        },
      ],
    },
    "conditional",
  );
  await assert.rejects(
    () =>
      d.review(
        actor,
        p.id,
        { version: p.version, decision: "approve" },
        "deny-pending",
      ),
    /conditions/,
  );
  const r = await d.review(
    actor,
    p.id,
    { version: p.version, decision: "approve", allowConditional: true },
    "conditional-approve",
  );
  assert.equal(r.state, "conditionally_authorized");
  assert.equal(
    (await s.query("SELECT id FROM jobs WHERE kind='execute_proposal'")).rows
      .length,
    0,
  );
});
test("public projection requires approval and refuses unconfirmed receipt", async (t) => {
  const { s, d } = await setup(t);
  await s.put("org0", "operation", "travel", { state: "dispatched" }, 0);
  const p = await d.draftPublication(
    actor,
    {
      title: "Aid received",
      text: "The shipment arrived",
      status: "received",
      operationIds: ["travel"],
    },
    "pubdraft",
  );
  assert.equal(p.state, "draft");
  await assert.rejects(
    () => d.publish(actor, p.id, { version: p.version }, "pubapprove"),
    /Receipt/,
  );
  await s.upsert("org0", "operation", "travel", {
    state: "received",
    confirmedBySource: true,
  });
  assert.equal(
    (await d.publish(actor, p.id, { version: p.version }, "pubapprove2")).state,
    "published",
  );
});
test("test payment signatures, duplicate webhooks, refunds and allocation are reconciled", async (t) => {
  const { s } = await setup(t);
  const f = new Finance(s, { secret: "test-signing-key" }),
    checkout = await f.checkout("org0", { amountCents: 5000 });
  const event = {
    org: "org0",
    id: checkout.id,
    eventId: "test-event-1",
    state: "settled",
  };
  await assert.rejects(() => f.webhook(event, "bad"), /signature/);
  await f.webhook(event, f.signature(event));
  await f.webhook(event, f.signature(event));
  assert.equal((await f.summary("org0")).receivedCents, 5000);
  const refund = { ...event, eventId: "test-refund-1", state: "refunded" };
  await f.webhook(refund, f.signature(refund));
  assert.equal((await f.summary("org0")).availableCents, 0);
  await assert.rejects(
    () => f.allocate(actor, { amountCents: 1, reason: "test" }, "allocate"),
    /insufficient/,
  );
});
